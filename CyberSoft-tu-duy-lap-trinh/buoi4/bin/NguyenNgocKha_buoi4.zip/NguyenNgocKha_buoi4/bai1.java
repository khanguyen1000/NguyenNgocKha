package NguyenNgocKha_buoi4;

public class bai1 {
	public static void main(String[] args) {
		// đầu vào
		int n = 1;
		int tog = 0;
		// xử lý
		while (tog < 5000) {
			tog += n;
			n++;
		}
		// đầu ra
		System.out.println(tog);
		System.out.println(n);
	}
}
