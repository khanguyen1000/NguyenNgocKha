package NguyenNgocKha_buoi4;

import java.util.Scanner;

public class bai4 {
	public static void main(String[] args) {
		// đầu vào
		Scanner sn = new Scanner(System.in);
		int n;
		int i = 1; // tịnh tiến
		int giaithua = 1;
		// nhập dữ liệu
		System.out.print("nhập n =");
		n = sn.nextInt();
		// xử lý

		while (i <= n) {
			if (n == 0 || n == 1) {
				giaithua = 1;
			} else {
				giaithua *= i;
			}
			i++;

		}
		// đầu ra
		System.out.println(n + "! = " + giaithua);

	}
}
