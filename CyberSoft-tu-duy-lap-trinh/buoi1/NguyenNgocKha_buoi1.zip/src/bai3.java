import java.util.Scanner;

public class bai3 {
	public static void main(String[] args) {
		Scanner sn=new Scanner(System.in);
		System.out.println("xin chào ");
		System.out.print("mời bạn nhập số usd cần quy đổi vnd :");
		float usd=sn.nextFloat();
		float vnd=(float)usd*23500;
		System.out.println(usd+" usd = "+vnd+" vnd");
	}
}
