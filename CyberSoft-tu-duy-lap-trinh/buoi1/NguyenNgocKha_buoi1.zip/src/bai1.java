import java.util.Scanner;

public class bai1 {

	public static void main(String[] args) {
		Scanner sn=new Scanner(System.in);
		System.out.println("-------------xin chào--------------");
		System.out.println("mời bạn nhập vào số ngày làm :");
		int ngayLam=sn.nextInt();
		int luong=ngayLam*100000; // 100k 1 ngày bèo qá anh ơi 
		System.out.println("lương của bạn là : "+luong );
	}

}
