import java.util.Scanner;

public class bai2 {

	public static void main(String[] args) {
		Scanner sn =new Scanner(System.in);
		System.out.println("Xin chào.!! mời bạn nhập vào 5 số thực ");
		float a,b,c,d,e;
		System.out.println("số thứ nhất a: " ); a=sn.nextFloat();
		System.out.println("số thứ hai b: " ); b=sn.nextFloat();
		System.out.println("số thứ ba c: " ); c=sn.nextFloat();
		System.out.println("số thứ tư d: " ); d=sn.nextFloat();
		System.out.println("số thứ năm e: " ); e=sn.nextFloat();
		float stb=(a+b+c+d+e)/5;
		System.out.println("tổng trung bình của 5 số này là : "+ stb);
	}

}
