import java.util.Scanner;

public class bai4 {
	public static void main(String[] args) {
		Scanner sn =new Scanner(System.in);
		System.out.println("xin chào :");
		System.out.println("mời nhập vào chiều dài và chiều rộng ");
		System.out.print("nhập vào chiều dài :");
		float cd=sn.nextFloat();
		System.out.print("nhập vào chiều rộng :");
		float cr=sn.nextFloat();
		float dt=cd*cr;
		float cv=(cd+cr)*2;
		System.out.println("diện tích : "+dt);
		System.out.println("chu vi : "+cv);
		
	}

}
