import java.util.Scanner;

public class bai5 {

	public static void main(String[] args) {
		Scanner sn=new Scanner(System.in); 
		System.out.println("xin chào");
		System.out.println("mời nhập 1 số nguyên có 2 chữ số ví dụ (11,14,55) :");
		int s=sn.nextInt();
		int so_hang_dv=s%10;
		int so_hang_chuc=s/10;
		int tong=so_hang_chuc+so_hang_dv;
		System.out.println("Tổng "+so_hang_chuc+" + "+so_hang_dv+" = "+ tong );
	
	} 

}
